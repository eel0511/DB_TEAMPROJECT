package Main;

import Database.*;
import UI.MainUI;

public class Main {

	public static void main(String[] args) {

		
		MainUI obj = new MainUI();
		
	}

}
